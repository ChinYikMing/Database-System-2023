public class Operation {
    public static final int INSERT = 1; 
    public static final int LOOKUP = 2; 
    // public static final int DELETE = 3; 
    public static final int DISPLAY = 3; 
    public static final int DISPLAYGUI = 4; 
    public static final int RANGESEARCH = 5; 
}
