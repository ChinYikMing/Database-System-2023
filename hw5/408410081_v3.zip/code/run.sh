javac Main.java
java Main
rm *.class
