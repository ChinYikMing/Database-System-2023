import java.util.ArrayList;
import java.util.List;

public class LookupPair {
    private List<Integer> result = new ArrayList<Integer>();
    public List<Integer> getResult() {
        return result;
    }

    private List<Integer> overflow = new ArrayList<Integer>();
    public List<Integer> getOverflow() {
        return overflow;
    }

    LookupPair(){

    }
}
